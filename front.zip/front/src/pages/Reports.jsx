import React, { useState, useEffect, useCallback } from 'react';
import PageHeader from '../components/PageHeader.jsx';
import {
  fetchCourtRoomFiles,
  fetchMovementReport,
  fetchUnknownTags,
  fetchCaseSummary,
  fetchDailyTagging,
  downloadReportCsv,
} from '../api/reports.js';
import {
  MapPinned,
  Activity,
  AlertTriangle,
  FileSpreadsheet,
  Download,
  Calendar,
  Search,
  Filter,
  Layers,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Clock,
  CheckCircle2,
  Eye,
  FileText,
  List,
} from 'lucide-react';
import { LocationBadge, DirectionBadge } from '../components/StatusBadge.jsx';
import FileDetailModal from '../components/FileDetailModal.jsx';
import './Reports.css';

const REPORT_TABS = [
  { id: 'court-room-files', label: 'Court Room Dwell', icon: MapPinned },
  { id: 'movements', label: 'Movement History', icon: Activity },
  { id: 'unknown-tags', label: 'Unknown EPC Scans', icon: AlertTriangle },
  { id: 'case-summary', label: 'Case-Level Summary', icon: Layers },
  { id: 'daily-report', label: 'Daily Reports', icon: CalendarDays },
];

// YYYY-MM-DD for the user's *local* calendar day (toISOString would give the UTC day,
// which is the wrong day for the first hours of the morning in India).
function toLocalDateString(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function formatDayLabel(dateStr) {
  // `T00:00:00` without a "Z" is parsed as local time, so the label never shifts a day
  return new Date(`${dateStr}T00:00:00`).toLocaleDateString('en-IN', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

const BROWSER_TIME_ZONE = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Kolkata';

const DAILY_PAGE_SIZES = [20, 50, 100];

// Page numbers to render, e.g. [1, 'gap-1', 4, 5, 6, 'gap-2', 20]. Strings are "…" gaps.
function getPageNumbers(current, total) {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const pages = new Set([1, total, current - 1, current, current + 1]);
  if (current <= 3) [2, 3, 4].forEach((p) => pages.add(p));
  if (current >= total - 2) [total - 1, total - 2, total - 3].forEach((p) => pages.add(p));
  const sorted = [...pages].filter((p) => p >= 1 && p <= total).sort((a, b) => a - b);
  const out = [];
  sorted.forEach((p, i) => {
    if (i > 0 && p - sorted[i - 1] > 1) out.push(`gap-${i}`);
    out.push(p);
  });
  return out;
}

export default function Reports() {
  const [activeTab, setActiveTab] = useState('court-room-files');
  const [datePreset, setDatePreset] = useState('all'); // 'today' | '7d' | '30d' | 'all' | 'custom'
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [gateFilter, setGateFilter] = useState('');
  const [directionFilter, setDirectionFilter] = useState('');
  const [caseSearch, setCaseSearch] = useState('CASE-1001');
  const [thresholdHours, setThresholdHours] = useState(4);
  const [page, setPage] = useState(1);
  const [dailySelectedDay, setDailySelectedDay] = useState('');
  const [dailyViewMode, setDailyViewMode] = useState('files'); // 'files' | 'summary'
  const [dailyPageSize, setDailyPageSize] = useState(DAILY_PAGE_SIZES[0]);

  // Data states
  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [exporting, setExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);
  const [selectedFileId, setSelectedFileId] = useState(null);

  const applyDatePreset = (preset) => {
    setDatePreset(preset);
    setPage(1);
    setDailySelectedDay('');
    const now = new Date();

    if (preset === 'today') {
      setFromDate(toLocalDateString(now));
      setToDate(toLocalDateString(now));
    } else if (preset === '7d') {
      const past = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      setFromDate(toLocalDateString(past));
      setToDate(toLocalDateString(now));
    } else if (preset === '30d') {
      const past = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      setFromDate(toLocalDateString(past));
      setToDate(toLocalDateString(now));
    } else if (preset === 'all') {
      setFromDate('');
      setToDate('');
    }
  };

  const loadReport = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = { page, limit: 30 };
      if (fromDate) params.from = `${fromDate}T00:00:00.000Z`;
      if (toDate) params.to = `${toDate}T23:59:59.999Z`;

      if (activeTab === 'court-room-files') {
        params.thresholdHours = thresholdHours;
        const res = await fetchCourtRoomFiles(params);
        setReportData(res);
      } else if (activeTab === 'movements') {
        if (gateFilter) params.gateId = gateFilter;
        if (directionFilter) params.direction = directionFilter;
        const res = await fetchMovementReport(params);
        setReportData(res);
      } else if (activeTab === 'unknown-tags') {
        if (gateFilter) params.gateId = gateFilter;
        const res = await fetchUnknownTags(params);
        setReportData(res);
      } else if (activeTab === 'case-summary') {
        if (!caseSearch.trim()) {
          setReportData(null);
          setLoading(false);
          return;
        }
        const res = await fetchCaseSummary(caseSearch.trim());
        setReportData(res);
      } else if (activeTab === 'daily-report') {
        // Daily report works on plain calendar days in the user's own time zone with pagination
        const dailyParams = { tz: BROWSER_TIME_ZONE, page, limit: dailyPageSize };
        if (fromDate) dailyParams.from = fromDate;
        if (toDate) dailyParams.to = toDate;
        if (dailySelectedDay) dailyParams.day = dailySelectedDay;
        const res = await fetchDailyTagging(dailyParams);
        setReportData(res);
      }
    } catch (err) {
      setError(err.message || 'Failed to generate report');
      setReportData(null);
    } finally {
      setLoading(false);
    }
  }, [activeTab, fromDate, toDate, gateFilter, directionFilter, caseSearch, thresholdHours, page, dailySelectedDay, dailyPageSize]);

  useEffect(() => {
    loadReport();
  }, [loadReport]);

  const handleExportCsv = async (format = 'csv') => {
    try {
      setExporting(true);
      setError(null);
      const params = {};
      if (activeTab === 'daily-report') {
        params.tz = BROWSER_TIME_ZONE;
        if (fromDate) params.from = fromDate;
        if (toDate) params.to = toDate;
        if (dailySelectedDay) params.day = dailySelectedDay;
        if (format) params.format = format;
      } else {
        if (fromDate) params.from = `${fromDate}T00:00:00.000Z`;
        if (toDate) params.to = `${toDate}T23:59:59.999Z`;
        if (gateFilter) params.gateId = gateFilter;
        if (directionFilter) params.direction = directionFilter;
        if (activeTab === 'court-room-files') params.thresholdHours = thresholdHours;
        if (activeTab === 'case-summary') params.caseId = caseSearch.trim();
        if (format) params.format = format;
      }

      await downloadReportCsv(activeTab, params);
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (err) {
      setError(err.message || 'Export failed');
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="reports-page">
      <div className="reports-header-actions">
        <PageHeader
          title="Operational & Historical Reports"
          subtitle="Generate, filter, and export court records, dwell audits, and movement registers"
        />
        <div style={{ display: 'flex', gap: '0.65rem', flexWrap: 'wrap' }}>
          <button
            className="btn-export-csv"
            onClick={() => handleExportCsv('csv')}
            disabled={exporting || loading}
            title="Download report as CSV"
          >
            {exporting ? (
              <span>Exporting...</span>
            ) : exportSuccess ? (
              <>
                <CheckCircle2 size={16} />
                <span>Downloaded!</span>
              </>
            ) : (
              <>
                <Download size={16} />
                <span>Export CSV</span>
              </>
            )}
          </button>
          {activeTab === 'daily-report' && (
            <button
              className="btn-export-csv report-export-btn-excel"
              onClick={() => handleExportCsv('xlsx')}
              disabled={exporting || loading}
              title="Download daily report as Excel spreadsheet (.xlsx)"
            >
              <FileSpreadsheet size={16} />
              <span>Export Excel</span>
            </button>
          )}
        </div>
      </div>

      {/* Report Navigation Tabs */}
      <div className="report-nav-tabs">
        {REPORT_TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            className={`report-tab-btn ${activeTab === id ? 'active' : ''}`}
            onClick={() => {
              setActiveTab(id);
              setPage(1);
              setDailySelectedDay('');
              setReportData(null); // don't render the previous tab's data in this tab's layout
            }}
          >
            <Icon size={16} />
            <span>{label}</span>
          </button>
        ))}
      </div>

      {/* Filter Bar */}
      <div className="report-filter-bar">
        <div className="filter-group-left">
          {activeTab !== 'case-summary' ? (
            <>
              <div className="date-preset-buttons">
                <button
                  className={`date-preset-btn ${datePreset === 'all' ? 'active' : ''}`}
                  onClick={() => applyDatePreset('all')}
                >
                  All Time
                </button>
                <button
                  className={`date-preset-btn ${datePreset === 'today' ? 'active' : ''}`}
                  onClick={() => applyDatePreset('today')}
                >
                  Today
                </button>
                <button
                  className={`date-preset-btn ${datePreset === '7d' ? 'active' : ''}`}
                  onClick={() => applyDatePreset('7d')}
                >
                  Last 7 Days
                </button>
                <button
                  className={`date-preset-btn ${datePreset === '30d' ? 'active' : ''}`}
                  onClick={() => applyDatePreset('30d')}
                >
                  Last 30 Days
                </button>
              </div>

              <div className="date-input-group">
                <Calendar size={15} />
                <input
                  type="date"
                  className="report-date-input"
                  value={fromDate}
                  onChange={(e) => {
                    setDatePreset('custom');
                    setFromDate(e.target.value);
                    setPage(1);
                    setDailySelectedDay('');
                  }}
                  title="From Date"
                />
                <span>to</span>
                <input
                  type="date"
                  className="report-date-input"
                  value={toDate}
                  onChange={(e) => {
                    setDatePreset('custom');
                    setToDate(e.target.value);
                    setPage(1);
                    setDailySelectedDay('');
                  }}
                  title="To Date"
                />
              </div>

              {activeTab === 'court-room-files' && (
                <div className="date-input-group" style={{ marginLeft: '0.5rem' }}>
                  <Clock size={15} />
                  <span>Threshold:</span>
                  <select
                    className="report-date-input"
                    value={thresholdHours}
                    onChange={(e) => setThresholdHours(Number(e.target.value))}
                  >
                    <option value={2}>2 Hours</option>
                    <option value={4}>4 Hours (Standard Court Session)</option>
                    <option value={6}>6 Hours</option>
                    <option value={8}>8 Hours (Full Shift)</option>
                  </select>
                </div>
              )}

              {activeTab === 'movements' && (
                <>
                  <select
                    className="report-date-input"
                    value={gateFilter}
                    onChange={(e) => {
                      setGateFilter(e.target.value);
                      setPage(1);
                    }}
                  >
                    <option value="">All Gates</option>
                    <option value="SHELF_ROOM_DOOR">Shelf / Record Room Door</option>
                    <option value="COURT_ROOM_DOOR">Court Room Door</option>
                  </select>

                  <select
                    className="report-date-input"
                    value={directionFilter}
                    onChange={(e) => {
                      setDirectionFilter(e.target.value);
                      setPage(1);
                    }}
                  >
                    <option value="">All Directions</option>
                    <option value="IN">IN (Entering)</option>
                    <option value="OUT">OUT (Exiting)</option>
                  </select>
                </>
              )}
            </>
          ) : (
            <div className="date-input-group" style={{ width: '320px' }}>
              <Search size={16} />
              <input
                type="text"
                className="report-date-input"
                style={{ width: '100%' }}
                placeholder="Enter Case ID (e.g. CASE-1001)"
                value={caseSearch}
                onChange={(e) => setCaseSearch(e.target.value)}
              />
            </div>
          )}
        </div>

        <button className="btn-action" onClick={loadReport} disabled={loading}>
          <span>{loading ? 'Refreshing...' : 'Apply Filters'}</span>
        </button>
      </div>

      {error && (
        <div
          style={{
            padding: '0.85rem 1.25rem',
            background: 'var(--red-bg)',
            border: '1px solid rgba(195, 63, 52, 0.3)',
            borderRadius: 'var(--radius-md)',
            color: 'var(--red-600)',
            marginBottom: '1.5rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            fontSize: '0.9rem',
          }}
        >
          <AlertTriangle size={18} />
          <span>{error}</span>
        </div>
      )}

      {/* Tab 1: Court Room Dwell Report */}
      {activeTab === 'court-room-files' && (
        <>
          <div className="report-summary-cards">
            <div className="report-summary-card">
              <div className="user-stat-title">Files in Courtroom</div>
              <div className="user-stat-value" style={{ color: 'var(--amber-600)' }}>
                {reportData?.total || 0}
              </div>
            </div>
            <div className="report-summary-card">
              <div className="user-stat-title">Overstay Alerts (&gt; {thresholdHours} hrs)</div>
              <div className="user-stat-value" style={{ color: 'var(--red-600)' }}>
                {reportData?.overstayCount || 0}
              </div>
            </div>
            <div className="report-summary-card">
              <div className="user-stat-title">Compliance Rate</div>
              <div className="user-stat-value" style={{ color: 'var(--green-600)' }}>
                {reportData?.total
                  ? `${Math.round(((reportData.total - reportData.overstayCount) / reportData.total) * 100)}%`
                  : '100%'}
              </div>
            </div>
          </div>

          <div className="report-table-card">
            <table className="users-table">
              <thead>
                <tr>
                  <th>File ID</th>
                  <th>File Name</th>
                  <th>Case Reference</th>
                  <th>Arrival Time</th>
                  <th>Time in Court</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={6} style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                      Calculating courtroom dwell times...
                    </td>
                  </tr>
                ) : !reportData?.items || reportData.items.length === 0 ? (
                  <tr>
                    <td colSpan={6} style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                      No files currently in the Courtroom for the selected criteria.
                    </td>
                  </tr>
                ) : (
                  reportData.items.map((file) => (
                    <tr
                      key={file.fileId}
                      className={`clickable-row ${file.overstay ? 'overstay-row' : ''}`}
                      onClick={() => setSelectedFileId(file.fileId)}
                    >
                      <td className="mono" style={{ fontWeight: 600 }}>{file.fileId}</td>
                      <td>{file.fileName}</td>
                      <td>
                        <div style={{ fontWeight: 500 }}>{file.caseId}</div>
                        <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{file.caseName}</div>
                      </td>
                      <td style={{ fontSize: '0.85rem' }}>
                        {file.lastMovementAt ? new Date(file.lastMovementAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '—'}
                      </td>
                      <td>
                        <strong style={{ color: file.overstay ? 'var(--red-600)' : 'var(--text)' }}>
                          {file.dwellHours} hrs
                        </strong>{' '}
                        <span style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>({file.dwellMinutes}m)</span>
                      </td>
                      <td>
                        {file.overstay ? (
                          <span className="user-status-badge inactive" style={{ display: 'inline-flex', gap: '4px' }}>
                            <AlertTriangle size={12} />
                            Overstay Alert
                          </span>
                        ) : (
                          <span className="user-status-badge active">
                            Normal Session
                          </span>
                        )}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* Tab 2: Movement History Report */}
      {activeTab === 'movements' && (
        <>
          <div className="report-summary-cards">
            <div className="report-summary-card">
              <div className="user-stat-title">Total Movements in Range</div>
              <div className="user-stat-value">{reportData?.total || 0}</div>
            </div>
            <div className="report-summary-card">
              <div className="user-stat-title">Current Page</div>
              <div className="user-stat-value">
                {reportData?.page || 1} of {reportData?.totalPages || 1}
              </div>
            </div>
          </div>

          <div className="report-table-card">
            <table className="users-table">
              <thead>
                <tr>
                  <th>Timestamp</th>
                  <th>File ID</th>
                  <th>Paired RFID Tag</th>
                  <th>Gate Door</th>
                  <th>Direction</th>
                  <th>Resulting Location</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={6} style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                      Loading movement records...
                    </td>
                  </tr>
                ) : !reportData?.items || reportData.items.length === 0 ? (
                  <tr>
                    <td colSpan={6} style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                      No scan movements logged in the selected date range.
                    </td>
                  </tr>
                ) : (
                  reportData.items.map((m) => (
                    <tr
                      key={m._id}
                      className="clickable-row"
                      onClick={() => setSelectedFileId(m.fileId)}
                    >
                      <td style={{ fontSize: '0.85rem' }}>{new Date(m.timestamp).toLocaleString()}</td>
                      <td className="mono" style={{ fontWeight: 600 }}>{m.fileId}</td>
                      <td className="mono" style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>{m.rfidTag}</td>
                      <td>{m.gateId === 'COURT_ROOM_DOOR' ? 'Court Room Door' : 'Shelf Room Door'}</td>
                      <td>
                        <DirectionBadge direction={m.direction} />
                      </td>
                      <td>
                        <LocationBadge location={m.resultingLocation} />
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>

            {reportData?.totalPages > 1 && (
              <div className="report-pagination">
                <span>
                  Showing page {reportData.page} of {reportData.totalPages} ({reportData.total} records)
                </span>
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <button
                    className="btn-action"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page <= 1}
                  >
                    <ChevronLeft size={15} />
                    <span>Previous</span>
                  </button>
                  <button
                    className="btn-action"
                    onClick={() => setPage((p) => Math.min(reportData.totalPages, p + 1))}
                    disabled={page >= reportData.totalPages}
                  >
                    <span>Next</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </>
      )}

      {/* Tab 3: Unknown Tags Report */}
      {activeTab === 'unknown-tags' && (
        <>
          <div className="report-summary-cards">
            <div className="report-summary-card">
              <div className="user-stat-title">Unregistered Tag Scans</div>
              <div className="user-stat-value" style={{ color: 'var(--amber-600)' }}>
                {reportData?.total || 0}
              </div>
            </div>
          </div>

          <div className="report-table-card">
            <table className="users-table">
              <thead>
                <tr>
                  <th>Timestamp</th>
                  <th>Unregistered RFID Tag EPC</th>
                  <th>Gate Door</th>
                  <th>Direction</th>
                  <th>Reader Device</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={5} style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                      Loading unknown scan events...
                    </td>
                  </tr>
                ) : !reportData?.items || reportData.items.length === 0 ? (
                  <tr>
                    <td colSpan={5} style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                      No unknown or unregistered tags detected in this range.
                    </td>
                  </tr>
                ) : (
                  reportData.items.map((u) => (
                    <tr key={u._id}>
                      <td style={{ fontSize: '0.85rem' }}>{new Date(u.timestamp).toLocaleString()}</td>
                      <td className="mono" style={{ fontWeight: 600, color: 'var(--amber-600)' }}>{u.rfidTag}</td>
                      <td>{u.gateId === 'COURT_ROOM_DOOR' ? 'Court Room Door' : 'Shelf Room Door'}</td>
                      <td>
                        <DirectionBadge direction={u.direction} />
                      </td>
                      <td style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>{u.deviceId || '—'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* Tab 4: Case Summary Report */}
      {activeTab === 'case-summary' && (
        <>
          {reportData && (
            <>
              <div className="report-summary-cards">
                <div className="report-summary-card">
                  <div className="user-stat-title">Case Title</div>
                  <div style={{ fontSize: '1.1rem', fontWeight: 600, marginTop: '4px' }}>
                    {reportData.caseName}
                  </div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>ID: {reportData.caseId}</div>
                </div>
                <div className="report-summary-card">
                  <div className="user-stat-title">Total File Bundles</div>
                  <div className="user-stat-value">{reportData.totalFiles}</div>
                </div>
                <div className="report-summary-card">
                  <div className="user-stat-title">In Shelf Room</div>
                  <div className="user-stat-value" style={{ color: 'var(--green-600)' }}>
                    {reportData.locationSummary?.SHELF_ROOM || 0}
                  </div>
                </div>
                <div className="report-summary-card">
                  <div className="user-stat-title">In Court Room</div>
                  <div className="user-stat-value" style={{ color: 'var(--amber-600)' }}>
                    {reportData.locationSummary?.COURT_ROOM || 0}
                  </div>
                </div>
                <div className="report-summary-card">
                  <div className="user-stat-title">In Transit</div>
                  <div className="user-stat-value" style={{ color: 'var(--purple-600)' }}>
                    {reportData.locationSummary?.IN_TRANSIT || 0}
                  </div>
                </div>
              </div>

              <div className="report-table-card">
                <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid var(--border)', fontWeight: 600 }}>
                  Case Files ({reportData.files?.length || 0})
                </div>
                <table className="users-table">
                  <thead>
                    <tr>
                      <th>File ID</th>
                      <th>File Name</th>
                      <th>Current Physical Location</th>
                      <th>Paired RFID Tag</th>
                      <th>Last Movement Time</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reportData.files?.map((f) => (
                      <tr
                        key={f.fileId}
                        className="clickable-row"
                        onClick={() => setSelectedFileId(f.fileId)}
                      >
                        <td className="mono" style={{ fontWeight: 600 }}>{f.fileId}</td>
                        <td>{f.fileName}</td>
                        <td>
                          <LocationBadge location={f.currentLocation} />
                        </td>
                        <td className="mono" style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>{f.rfidTag}</td>
                        <td style={{ fontSize: '0.85rem' }}>
                          {f.lastMovementAt ? new Date(f.lastMovementAt).toLocaleString() : '—'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </>
      )}

      {/* Tab 5: Daily Reports (files tagged per day) */}
      {activeTab === 'daily-report' && (() => {
        const daily = reportData?.report === 'daily-tagging' ? reportData : null;
        const peakCount = daily?.peakDay?.filesTagged || 0;

        return (
          <>
            <div className="report-summary-cards">
              <div className="report-summary-card">
                <div className="user-stat-title">Tagged Today</div>
                <div className="user-stat-value" style={{ color: 'var(--accent-600)' }}>
                  {daily?.today?.filesTagged ?? 0}
                </div>
              </div>
              <div className="report-summary-card">
                <div className="user-stat-title">Tagged Yesterday</div>
                <div className="user-stat-value">{daily?.yesterday?.filesTagged ?? 0}</div>
              </div>
              <div className="report-summary-card">
                <div className="user-stat-title">Total in Selected Range</div>
                <div className="user-stat-value" style={{ color: 'var(--green-600)' }}>
                  {daily?.totalTagged ?? 0}
                </div>
              </div>
              <div className="report-summary-card">
                <div className="user-stat-title">Average per Working Day</div>
                <div className="user-stat-value">{daily?.averagePerDay ?? 0}</div>
              </div>
              <div className="report-summary-card">
                <div className="user-stat-title">Best Day</div>
                <div className="user-stat-value" style={{ color: 'var(--amber-600)' }}>
                  {daily?.peakDay ? daily.peakDay.filesTagged : 0}
                </div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                  {daily?.peakDay ? formatDayLabel(daily.peakDay.date) : '—'}
                </div>
              </div>
            </div>

            <div className="report-table-card">
              <div className="daily-table-header-row">
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
                  <h3 style={{ margin: 0, fontSize: '1.05rem', fontWeight: 600 }}>
                    {dailyViewMode === 'files' ? 'Daily Edited Files' : 'Daily Tagging Summary'}
                  </h3>
                  {daily?.files && dailyViewMode === 'files' && (
                    <span className="user-status-badge active" style={{ fontSize: '0.75rem' }}>
                      {daily.files.total} total {daily.files.total === 1 ? 'file' : 'files'}
                    </span>
                  )}
                  {dailySelectedDay && (
                    <span
                      className="user-status-badge active"
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '0.35rem',
                        cursor: 'pointer',
                        fontSize: '0.75rem',
                      }}
                      onClick={() => {
                        setDailySelectedDay('');
                        setPage(1);
                      }}
                      title="Click to clear filter"
                    >
                      Filtered: {formatDayLabel(dailySelectedDay)} ✕
                    </span>
                  )}
                </div>

                <div className="daily-view-toggle">
                  <button
                    className={`daily-view-toggle-btn ${dailyViewMode === 'files' ? 'active' : ''}`}
                    onClick={() => setDailyViewMode('files')}
                  >
                    <List size={14} />
                    <span>Files List</span>
                  </button>
                  <button
                    className={`daily-view-toggle-btn ${dailyViewMode === 'summary' ? 'active' : ''}`}
                    onClick={() => setDailyViewMode('summary')}
                  >
                    <CalendarDays size={14} />
                    <span>Daily Summary</span>
                  </button>
                </div>
              </div>

              {dailyViewMode === 'files' ? (
                <>
                  <table className="users-table">
                    <thead>
                      <tr>
                        <th style={{ width: '60px' }}>#</th>
                        <th>File Name</th>
                        <th style={{ width: '120px', textAlign: 'center' }}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {loading ? (
                        <tr>
                          <td colSpan={3} style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                            Loading edited files...
                          </td>
                        </tr>
                      ) : !daily?.files?.items || daily.files.items.length === 0 ? (
                        <tr>
                          <td colSpan={3} style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                            No files were edited in the selected date range.
                          </td>
                        </tr>
                      ) : (
                        daily.files.items.map((file, idx) => (
                          <tr key={file.fileId + (file.editedAt || idx)}>
                            <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                              {((daily.files.page || 1) - 1) * (daily.files.limit || 20) + idx + 1}
                            </td>
                            <td>
                              <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                                <FileText size={17} style={{ color: 'var(--accent-600)', flexShrink: 0 }} />
                                <span style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{file.fileName}</span>
                                {file.day && (
                                  <span className="user-status-badge daily-day-badge daily-day-badge-muted" style={{ marginLeft: 'auto' }}>
                                    {formatDayLabel(file.day)}
                                  </span>
                                )}
                              </div>
                            </td>
                            <td style={{ textAlign: 'center' }}>
                              <button
                                className="btn-action"
                                onClick={() => setSelectedFileId(file.fileId)}
                                title="View File Details"
                              >
                                <Eye size={15} />
                                <span>View</span>
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>

                  {/* Always visible (even for a single page) so users can see totals and change page size */}
                  {daily?.files && (() => {
                    const { total, page: curPage, limit: curLimit, totalPages, items: pageItems } = daily.files;
                    const startNo = total === 0 ? 0 : (curPage - 1) * curLimit + 1;
                    const endNo = total === 0 ? 0 : startNo + pageItems.length - 1;
                    return (
                      <div className="report-pagination daily-pagination">
                        <span>
                          {total === 0 ? 'No files' : `Showing ${startNo}–${endNo} of ${total} ${total === 1 ? 'file' : 'files'}`}
                        </span>

                        <div className="daily-pagination-controls">
                          <label className="daily-page-size">
                            <span>Rows per page</span>
                            <select
                              className="report-date-input"
                              value={dailyPageSize}
                              onChange={(e) => {
                                setDailyPageSize(Number(e.target.value));
                                setPage(1);
                              }}
                            >
                              {DAILY_PAGE_SIZES.map((n) => (
                                <option key={n} value={n}>{n}</option>
                              ))}
                            </select>
                          </label>

                          <div className="daily-page-buttons">
                            <button
                              className="btn-action"
                              onClick={() => setPage((p) => Math.max(1, p - 1))}
                              disabled={curPage <= 1 || loading}
                            >
                              <ChevronLeft size={15} />
                              <span>Previous</span>
                            </button>

                            {getPageNumbers(curPage, totalPages).map((p) =>
                              typeof p === 'string' ? (
                                <span key={p} className="daily-page-gap">…</span>
                              ) : (
                                <button
                                  key={p}
                                  className={`daily-page-num ${p === curPage ? 'active' : ''}`}
                                  onClick={() => setPage(p)}
                                  disabled={loading}
                                  aria-current={p === curPage ? 'page' : undefined}
                                >
                                  {p}
                                </button>
                              )
                            )}

                            <button
                              className="btn-action"
                              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                              disabled={curPage >= totalPages || loading}
                            >
                              <span>Next</span>
                              <ChevronRight size={15} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })()}
                </>
              ) : (
                <>
                  <table className="users-table">
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Files Tagged</th>
                        <th>First-time Tags</th>
                        <th>Re-assigned Tags</th>
                        <th>Tagged By</th>
                        <th style={{ width: '100px', textAlign: 'center' }}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {loading ? (
                        <tr>
                          <td colSpan={6} style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                            Counting tagged files per day...
                          </td>
                        </tr>
                      ) : !daily || daily.items.length === 0 ? (
                        <tr>
                          <td colSpan={6} style={{ textAlign: 'center', padding: '2.5rem', color: 'var(--text-muted)' }}>
                            No files were tagged in the selected date range.
                          </td>
                        </tr>
                      ) : (
                        daily.items.map((row) => (
                          <tr key={row.date}>
                            <td style={{ fontWeight: 600 }}>
                              {formatDayLabel(row.date)}
                              {row.date === daily.today?.date && (
                                <span className="user-status-badge active daily-day-badge">Today</span>
                              )}
                              {row.date === daily.yesterday?.date && (
                                <span className="user-status-badge daily-day-badge daily-day-badge-muted">Yesterday</span>
                              )}
                            </td>
                            <td>
                              <div className="daily-count-cell">
                                <strong>{row.filesTagged}</strong>
                                <div className="daily-bar-track">
                                  <div
                                    className="daily-bar-fill"
                                    style={{ width: `${peakCount ? Math.max(4, (row.filesTagged / peakCount) * 100) : 0}%` }}
                                  />
                                </div>
                              </div>
                            </td>
                            <td>{row.firstTime}</td>
                            <td>{row.reassigned}</td>
                            <td style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                              {row.byUser.map((u) => `${u.username} (${u.count})`).join(', ') || '—'}
                            </td>
                            <td style={{ textAlign: 'center' }}>
                              <button
                                className="btn-action"
                                onClick={() => {
                                  setDailySelectedDay(row.date);
                                  setDailyViewMode('files');
                                  setPage(1);
                                }}
                                title="View files edited on this day"
                              >
                                <Eye size={14} />
                                <span>Files</span>
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </>
              )}
            </div>
          </>
        );
      })()}

      {selectedFileId && (
        <FileDetailModal
          fileId={selectedFileId}
          onClose={() => setSelectedFileId(null)}
          onFileUpdated={loadReport}
        />
      )}
    </div>
  );
}