import React, { useState, useEffect } from 'react';
import { X, AlertTriangle, Save } from 'lucide-react';
import { updateFile } from '../api/files.js';
import { LocationBadge } from './StatusBadge.jsx';
import { normalizeRfidTag } from '../utils/rfid.js';
import './EditFileModal.css';

export default function EditFileModal({ file, onClose, onSaveSuccess }) {
  const [formData, setFormData] = useState({
    fileName: '',
    caseId: '',
    rfidTag: '',
    caseNumber: '',
    cino: '',
    fileNumber: '',
    storageLocation: '',
    caseType: '',
    caseStatus: 'PENDING',
    reason: '',
  });
  const [originalTag, setOriginalTag] = useState('');
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (file) {
      setFormData({
        fileName: file.fileName || '',
        caseId: file.caseId || '',
        rfidTag: file.rfidTag || '',
        caseNumber: file.caseNumber || '',
        cino: file.cino || '',
        fileNumber: file.fileNumber || '',
        storageLocation: file.storageLocation || '',
        caseType: file.caseType || '',
        caseStatus: file.caseStatus || 'PENDING',
        reason: '',
      });
      setOriginalTag(file.rfidTag || '');
    }
  }, [file]);

  if (!file) return null;

  const isTagChanged = originalTag && formData.rfidTag && normalizeRfidTag(formData.rfidTag) !== originalTag;

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!formData.fileName.trim() || !formData.caseId.trim()) {
      setError('File Name and Case ID are required');
      return;
    }

    try {
      setSaving(true);
      setError(null);
      const payload = {
        fileName: formData.fileName.trim(),
        caseId: formData.caseId.trim(),
        ...(formData.rfidTag.trim() ? { rfidTag: normalizeRfidTag(formData.rfidTag) } : {}),
        caseNumber: formData.caseNumber.trim(),
        cino: formData.cino.trim().toUpperCase(),
        fileNumber: formData.fileNumber.trim(),
        storageLocation: formData.storageLocation.trim(),
        caseType: formData.caseType.trim().toUpperCase(),
        caseStatus: formData.caseStatus,
        reason: formData.reason.trim(),
      };
      const updated = await updateFile(file.fileId, payload);
      if (onSaveSuccess) onSaveSuccess(updated);
      onClose();
    } catch (err) {
      setError(err.message || 'Failed to update file record');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="edit-modal-panel" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="edit-modal-header">
          <div>
            <h3>Edit File Record</h3>
            <p className="edit-modal-subtitle">
              File ID: <strong style={{ fontFamily: 'var(--font-mono)' }}>{file.fileId}</strong>
            </p>
          </div>
          <button className="modal-close-btn" onClick={onClose} aria-label="Close">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="edit-modal-body">
            {/* 1. File ID */}
            <div className="edit-field">
              <label className="edit-field-label">1. File ID (Permanent)</label>
              <div className="edit-readonly-box mono">
                <span>{file.fileId}</span>
                <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Read-only</span>
              </div>
            </div>

            {/* 2. Current Location */}
            <div className="edit-field">
              <label className="edit-field-label">2. Current Physical Location</label>
              <div className="edit-readonly-box">
                <LocationBadge location={file.currentLocation} />
                <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>Movement Derived</span>
              </div>
            </div>

            {/* 3. File / Document Title */}
            <div className="edit-field">
              <label className="edit-field-label" htmlFor="edit-fileName">
                3. File / Document Title
              </label>
              <input
                id="edit-fileName"
                type="text"
                className="edit-field-input"
                placeholder="Enter file title"
                value={formData.fileName}
                onChange={(e) => setFormData({ ...formData, fileName: e.target.value })}
                required
              />
            </div>

            {/* 4. Case ID */}
            <div className="edit-field">
              <label className="edit-field-label" htmlFor="edit-caseId">
                4. Case ID
              </label>
              <input
                id="edit-caseId"
                type="text"
                className="edit-field-input"
                placeholder="e.g. CASE-1002"
                value={formData.caseId}
                onChange={(e) => setFormData({ ...formData, caseId: e.target.value })}
                required
              />
            </div>

            {/* CINO & Case Number */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="edit-field">
                <label className="edit-field-label" htmlFor="edit-cino">
                  CINO
                </label>
                <input
                  id="edit-cino"
                  type="text"
                  className="edit-field-input mono"
                  placeholder="e.g. UPHC010000012024"
                  value={formData.cino}
                  onChange={(e) => setFormData({ ...formData, cino: e.target.value.toUpperCase() })}
                />
              </div>
              <div className="edit-field">
                <label className="edit-field-label" htmlFor="edit-caseNumber">
                  Case Number
                </label>
                <input
                  id="edit-caseNumber"
                  type="text"
                  className="edit-field-input"
                  placeholder="e.g. BAIL/2024/001"
                  value={formData.caseNumber}
                  onChange={(e) => setFormData({ ...formData, caseNumber: e.target.value })}
                />
              </div>
            </div>

            {/* Case Type & Case Status */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
              <div className="edit-field">
                <label className="edit-field-label" htmlFor="edit-caseType">
                  Case Type
                </label>
                <input
                  id="edit-caseType"
                  type="text"
                  className="edit-field-input mono"
                  placeholder="e.g. BAIL, WTAX"
                  value={formData.caseType}
                  onChange={(e) => setFormData({ ...formData, caseType: e.target.value.toUpperCase() })}
                />
              </div>
              <div className="edit-field">
                <label className="edit-field-label" htmlFor="edit-caseStatus">
                  Case Status
                </label>
                <select
                  id="edit-caseStatus"
                  className="edit-field-input"
                  value={formData.caseStatus}
                  onChange={(e) => setFormData({ ...formData, caseStatus: e.target.value })}
                >
                  <option value="PENDING">PENDING</option>
                  <option value="DISPOSED">DISPOSED</option>
                </select>
              </div>
            </div>

            {/* File Number */}
            <div className="edit-field">
              <label className="edit-field-label" htmlFor="edit-fileNumber">
                File Number
              </label>
              <input
                id="edit-fileNumber"
                type="text"
                className="edit-field-input"
                placeholder="e.g. 1001/2024"
                value={formData.fileNumber}
                onChange={(e) => setFormData({ ...formData, fileNumber: e.target.value })}
              />
            </div>

            {/* Location (free text, shown on the handheld search screen) */}
            <div className="edit-field">
              <label className="edit-field-label" htmlFor="edit-storageLocation">
                Location
              </label>
              <input
                id="edit-storageLocation"
                type="text"
                className="edit-field-input"
                placeholder="e.g. Room 12, Rack A-3, Shelf 2"
                maxLength={200}
                value={formData.storageLocation}
                onChange={(e) => setFormData({ ...formData, storageLocation: e.target.value })}
              />
              <span style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
                Where this file is kept. Shown on the handheld search screen.
              </span>
            </div>

            {/* Paired RFID Tag */}
            <div className="edit-field">
              <label className="edit-field-label" htmlFor="edit-rfidTag">
                Paired RFID EPC Tag (Optional for unmapped)
              </label>
              <input
                id="edit-rfidTag"
                type="text"
                className="edit-field-input mono"
                placeholder="Leave blank if pending mapping"
                value={formData.rfidTag}
                onChange={(e) => setFormData({ ...formData, rfidTag: e.target.value })}
              />

              {isTagChanged && (
                <div className="edit-tag-warning">
                  <div className="tag-warning-header">
                    <AlertTriangle size={17} />
                    <span>RFID Tag Modification Notice</span>
                  </div>
                  <div>
                    You are reassigning this file from tag <code>{originalTag}</code> to{' '}
                    <code>{formData.rfidTag}</code>. This change will be permanently logged in the audit trail.
                  </div>
                </div>
              )}
            </div>

            {/* 7. Reason for Edit */}
            <div className="edit-field">
              <label className="edit-field-label" htmlFor="edit-reason">
                7. Reason for Edit (Audit Note)
              </label>
              <input
                id="edit-reason"
                type="text"
                className="edit-field-input"
                placeholder="Optional"
                value={formData.reason}
                onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              />
            </div>
          </div>

          {error && (
            <div
              style={{
                margin: '0 1.75rem 1rem',
                padding: '0.85rem 1rem',
                background: '#fef2f2',
                border: '1px solid #fecaca',
                borderRadius: '8px',
                color: '#b91c1c',
                fontSize: '0.88rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
              }}
            >
              <AlertTriangle size={18} />
              <span>{error}</span>
            </div>
          )}

          {/* Footer */}
          <div className="edit-modal-footer">
            <button type="button" className="btn-action" onClick={onClose}>
              Cancel
            </button>
            <button
              type="submit"
              className="btn-primary"
              disabled={saving}
            >
              <Save size={16} />
              <span>{saving ? 'Saving...' : 'Save Changes'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}